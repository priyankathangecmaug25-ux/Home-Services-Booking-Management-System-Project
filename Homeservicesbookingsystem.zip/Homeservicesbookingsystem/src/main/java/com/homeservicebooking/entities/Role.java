package com.homeservicebooking.entities;

public enum Role {
	 USER, ADMIN

}