package com.homeservicebooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeservicesbookingsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeservicesbookingsystemApplication.class, args);
	}

}
