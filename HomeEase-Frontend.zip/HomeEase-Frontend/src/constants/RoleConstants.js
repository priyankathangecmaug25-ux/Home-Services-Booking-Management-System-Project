export const ROLES = {
    ADMIN:'ADMIN',
    USER:'USER'
}


